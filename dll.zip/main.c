/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
struct emp{
    char ssn[20],nm[20],dept[20],des[20];
    float sal;
};
typedef struct emp e;
struct node
{
    e d;
    struct node *llink,*rlink;
};
typedef struct node nd;
void i_f(nd *);
void i_r(nd *);
void d_f(nd *);
void d_r(nd *);
void display(nd *);
int main()
{
    nd header={.llink=0,.rlink=0};
    int ch,n;
    for(;;)
    {
        printf("1:create dll using end insertion\n2:display and count nodes\n3:insert front\n4:delete front\n5:insert rear\n6:delete rear\n7:exit\n");
        printf("Enter the choice\n");
        scanf("%d",&ch);
        switch(ch)
        {
            case 1 :  printf("Enter the values of n \n");
                      scanf("%d",&n);
                      for(int i=0;i<n;i++)
                        i_r(&header); break;
            case 2 : display(&header); break;
            case 3 : i_f(&header); break;
            case 4 : d_f(&header); break;
            case 5 : i_r(&header); break;
            case 6 : d_r(&header); break;
            case 7: 
                      printf("To show stack\n");
                      printf("8 to insertfront \n 9 to delete rear\n");
                      scanf("%d",&ch);
                      switch(ch)
                      {
                      case 8: i_f(&header); break;
                      case 9: d_f(&header); break;
                      }
            default : exit(0);
        }
    }
  
    
    return 0;
}

void i_f(nd *h)
{
    nd *t;
    t=(nd *)malloc(sizeof(nd));
    printf("Enter the employee details\n");
    scanf("%s%s%s%s%f",(t->d).ssn,(t->d).nm,(t->d).dept,(t->d).des,&(t->d).sal);
    t->rlink=t->llink=0;
    if(h->rlink==0)
    {
        h->rlink=t;
        return;
    }
    t->rlink=h->rlink;
    (h->rlink)->llink=t;
    h->rlink=t;
}
void d_f(nd *h)
{
    if(h->rlink==0)
    {
        printf("Dll is empty\n");
        return;
    }
    nd *t=h->rlink;
    printf("The elements deleted are %s %s %s %s %f\n",(t->d).ssn,(t->d).nm,(t->d).dept,(t->d).des,(t->d).sal);
    if((h->rlink)->rlink==0)
    {
        
        free(t);
        h->rlink=0;
        return;
        
    }
    h->rlink=t->rlink;
    (h->rlink)->llink=0;
    free(t);
}


void d_r(nd *h)
{
    if(h->rlink==0)
    {
        printf("Dll is empty\n");
        return;
    }
    if((h->rlink)->rlink==0)
    {
        d_f(h);
        return;
    }
    nd *p,*c;
    for(p=0,c=h;c->rlink!=0;p=c,c=c->rlink);
    printf("The elements deleted are %s %s %s %s %f\n",(c->d).ssn,(c->d).nm,(c->d).dept,(c->d).des,(c->d).sal);
    p->rlink=0;
    free(c);
}

void i_r(nd *h)
{
    nd *t;
    t=(nd *)malloc(sizeof(nd));
    printf("Enter the employee details\n");
    scanf("%s%s%s%s%f",(t->d).ssn,(t->d).nm,(t->d).dept,(t->d).des,&(t->d).sal);
    t->rlink=t->llink=0;
    if(h->rlink==0)
    {
        h->rlink=t;
        return;
    }
    nd *l;
    for(l=h;l->rlink!=0;l=l->rlink);
    t->llink=l;
    l->rlink=t;

}
void display(nd *h)
{
    if(h->rlink==0)
    {
        printf("Dll is empty\n");
        return;
    }
    nd *t=h->rlink;
    for(;t!=0;t=t->rlink)
    printf("The elements present are %s %s %s %s %f\n",(t->d).ssn,(t->d).nm,(t->d).dept,(t->d).des,(t->d).sal);
}
